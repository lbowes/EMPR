#define GM_CLZ(result, operand) asm ("clz %0, %1": "=d"(result): "d"(operand));

struct network_block {
	int a;	int d;	short c;
	char b;
};

#define NumBlocks (18)

struct network_block Blocks[NumBlocks];
const int BlocksStart = (int) (&Blocks[0]);
const int BlocksEnd = (int) (&Blocks[NumBlocks-1]);
// Bit array
// 1 = free, 0 = busy
// Bits are numbered from the top end. i.e. bit 31 = block 0.
unsigned int BusyList = 0;

#define Error (0)
#define OK (1)

void BlockInit() {
	int i;
	for(i=32-NumBlocks; i<32; i++) {
		BusyList |= 1<<i;
	}
}

struct network_block * BlockAllocate() {
	int b;
	
	// Find first candidate free block
	GM_CLZ(b, BusyList);			// Return number of 0's before the first 1, working from the MSB
						// So no unused blocks returns 0, for example.

	if(b >= NumBlocks) {			// Error return. No block available.
		return 0;
	}
	BusyList &= ~(1<<(31-b));		// Mark as allocated
	return &Blocks[b];
}

int BlockFree(struct network_block *n) {
	int in = (int)n;
	if((in & 0x3) || 					// badly aligned
	(in < BlocksStart) || 				// out of range
	(in > BlocksEnd)) return Error;		// out of range

	// Address is OK. So calculate which bit it corresponds to in the free list
	int index = 31-((in-BlocksStart)/sizeof(struct network_block));
	// and mark the block as free
	BusyList |= 1<<index;

	return OK;
}


